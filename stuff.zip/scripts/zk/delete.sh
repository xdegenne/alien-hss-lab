#!/bin/bash
echo "`date`: zookeeper - deleting ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: zookeeper - ... deleted !" >> /tmp/hss.log
