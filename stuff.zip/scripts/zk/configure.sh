#!/bin/bash
echo "`date`: zookeeper - configuring ..." >> /tmp/hss.log
echo "`date`: Zookeeper IP ------------------------------------------------------" >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
echo "`set | grep 'ip_address'`" >> /tmp/hss.log
echo "`date`: Zookeeper IP ------------------------------------------------------" >> /tmp/hss.log
sleep 5
echo "`date`: zookeeper - ... configured !" >> /tmp/hss.log
