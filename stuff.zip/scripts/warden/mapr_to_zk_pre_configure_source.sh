#!/bin/bash
echo "`date`: To ZK pre configuring src" >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: To ZK pre configured src" >> /tmp/hss.log
