#!/bin/bash
echo "`date`: wraden - deleting ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: wraden - ... deleted !" >> /tmp/hss.log
