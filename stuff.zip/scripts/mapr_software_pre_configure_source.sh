#!/bin/bash
echo "`date`: Software pre configuring src" >> /tmp/hss.log
sleep 5
echo "`date`: Software pre configured src" >> /tmp/hss.log
