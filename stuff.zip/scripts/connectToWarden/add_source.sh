#!/bin/bash
echo "`date`: connectToWarden - adding source ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: connectToWarden - warden: source added !" >> /tmp/hss.log
