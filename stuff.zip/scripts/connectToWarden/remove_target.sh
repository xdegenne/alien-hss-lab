#!/bin/bash
echo "`date`: connectToWarden - removing target ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: connectToWarden - ... target removed !" >> /tmp/hss.log
