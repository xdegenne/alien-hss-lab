#!/bin/bash
echo "`date`: connectToWarden - adding target ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: connectToWarden -  -target added !" >> /tmp/hss.log
