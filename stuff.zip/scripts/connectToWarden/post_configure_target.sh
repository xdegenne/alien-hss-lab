#!/bin/bash
echo "`date`: connectToWarden - post target configuring ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: connectToWarden - ... post target configured !" >> /tmp/hss.log
