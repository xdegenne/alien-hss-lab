#!/bin/bash
echo "`date`: core - post starting ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: core - ... post started !" >> /tmp/hss.log
