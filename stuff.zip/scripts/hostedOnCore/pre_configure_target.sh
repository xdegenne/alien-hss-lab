#!/bin/bash
echo "`date`: hostedOnCore - pre configuring target ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: hostedOnCore - ... target pre configured !" >> /tmp/hss.log
