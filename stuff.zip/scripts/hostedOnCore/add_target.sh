#!/bin/bash
echo "`date`: hostedOnCore - adding target ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: hostedOnCore -... target added !" >> /tmp/hss.log
