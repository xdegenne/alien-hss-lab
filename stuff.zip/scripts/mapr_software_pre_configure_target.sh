#!/bin/bash
echo "`date`: Software pre configuring tgt" >> /tmp/hss.log
sleep 5
echo "`date`: Software pre configured tgt" >> /tmp/hss.log
