#!/bin/bash
echo "`date`: hostedOnWarden - pre configuring target ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: hostedOnWarden - ... target pre configured !" >> /tmp/hss.log
