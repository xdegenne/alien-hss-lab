#!/bin/bash
echo "`date`: hostedOnWarden - removing target ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: hostedOnWarden - ... target removed !" >> /tmp/hss.log
