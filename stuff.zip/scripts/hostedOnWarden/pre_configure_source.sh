#!/bin/bash
echo "`date`: hostedOnWarden - pre configuring source ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: hostedOnWarden - ... source pre configured !" >> /tmp/hss.log
