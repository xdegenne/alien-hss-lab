#!/bin/bash
echo "`date`: connectToZK - pre configuring source ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: connectToZK - ... source pre configured !" >> /tmp/hss.log
