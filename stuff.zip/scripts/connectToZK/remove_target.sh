#!/bin/bash
echo "`date`: connectToZK - removing target ..." >> /tmp/hss.log
echo "`set | grep 'a4c_lab_'`" >> /tmp/hss.log
sleep 5
echo "`date`: connectToZK - ... target removed !" >> /tmp/hss.log
